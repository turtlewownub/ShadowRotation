---
name: Feature request
about: Suggest an improvement
title: "[Feature] "
labels: enhancement
---

**Problem or goal**

**Requested behavior**

**Why it would help**
