---
name: Bug report
about: Report a ShadowRotation problem
title: "[Bug] "
labels: bug
---

**Version**
Paste `/shadow version`.

**Module status**
Paste `/shadow modules`.

**What happened?**

**Exact error text**

**Steps to reproduce**
