# ShadowRotation v1.0.0

First public release of ShadowRotation for Turtle WoW.

## Installation

Download `ShadowRotation_v1.0.0_SHAREABLE_INSTALL.zip`, extract the included `ShadowRotation` folder into `Turtle WoW/Interface/AddOns/`, and restart the game.

Run:

```text
/shadow version
/shadow modules
```

The module check should finish with `System Status: READY`.
